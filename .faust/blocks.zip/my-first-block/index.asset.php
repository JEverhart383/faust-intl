<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-hooks'), 'version' => '1fd89b76b9bbb05e9e97');
